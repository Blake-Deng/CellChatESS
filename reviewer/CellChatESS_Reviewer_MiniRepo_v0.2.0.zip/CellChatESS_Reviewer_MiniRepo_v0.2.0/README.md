# CellChatESS v0.2.0 reviewer mini repository

This repository is the shortest reproducible route to the central software
claim:

> `threads = 1L` uses a true serial path; `threads > 1L` uses deterministic
> OpenMP bootstrap parallelism; both produce the same CellChat outputs.

The repository contains the complete CellChatESS package source, one prepared
PBMC3k CellChat object, an original CellChat reference result, and one script
that installs the bundled source into a private local library and verifies all
reported outputs.

The accompanying manuscript's principal runtime and memory comparisons use one
thread per method. This mini repository demonstrates the optional conditional
OpenMP implementation and numerical equivalence; its four-thread timing is a
resource-sensitivity check, not a replacement for the manuscript's controlled
one-thread benchmark.

## One-command review

Prerequisites are R (>= 4.1), Rcpp, and CellChat. From this directory:

```sh
Rscript run_review_demo.R
```

The script does not modify the reviewer's normal R library. It installs the
bundled package under `.review_lib/`, runs the same prepared object with one
and four requested threads, writes machine-readable results under `results/`,
and stops with a non-zero exit code if any numerical check fails.

Expected final message:

```text
PASS: serial and OpenMP results are identical; both match original CellChat.
```

## Implementation at a glance

```mermaid
flowchart LR
    A["computeCommunProbESS(threads = T)"] --> B{"T == 1?"}
    B -->|Yes| C["Serial bootstrap loop<br/>no OpenMP region"]
    B -->|No| D["OpenMP bootstrap loop<br/>thread-private scratch"]
    C --> E["Shared process_bootstrap() formula"]
    D --> E
    E --> F["CellChat-compatible<br/>probability and p-value tensors"]
```

OpenMP is applied inside each ligand-receptor interaction across bootstrap
permutations. The ligand-receptor loop remains serial because it shares a lazy
triMean cache. Each OpenMP worker owns its temporary expression and rejection
buffers, and integer rejection counts are reduced deterministically.

## What the script verifies

- one-thread versus four-thread probability tensors are exactly identical;
- p-value tensors are exactly identical;
- pathway probabilities and aggregate weights are exactly identical;
- aggregate counts are exactly identical;
- both runs agree with the bundled original CellChat reference within
  floating-point tolerance;
- `threads_requested` and `threads_used` are reported;
- repeated execution uses `nboot = 100` and `seed.use = 1L`.

On a build without OpenMP, the four-thread request safely falls back to one
thread; all numerical checks still run.

## Files worth opening

- `CellChatESS/R/accel_cellchat.R`: public `threads` argument and provenance.
- `CellChatESS/src/cellchat_prob_cpp.cpp`: serial/OpenMP branch and shared
  bootstrap worker.
- `CellChatESS/src/Makevars`: portable R OpenMP flags.
- `run_review_demo.R`: complete one-command validation.
- `expected/acceptance.tsv`: explicit pass thresholds.
- `REVIEWER_CHECKLIST.md`: five-minute code-review route.

## Scope

The demo targets the supported CellChatESS workflow: a single non-spatial RNA
dataset, `type = "triMean"`, `population.size = FALSE`, `nboot = 100`,
and `seed.use = 1L`. OpenMP improves implementation efficiency but does not
remove the intrinsic quadratic sender-receiver output term.
